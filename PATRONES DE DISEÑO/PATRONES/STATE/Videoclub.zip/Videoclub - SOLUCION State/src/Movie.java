

/**
 * Cambios frente a la versi�n vista en clase:
 * 	La clase Movie "oculta" al resto de clases que la utilizan el hecho de su "tipo" de codifique como un objeto de la clase "MovieType" (Estado)
 *  Para ello implementa directamente las operaciones de calculo de alquier (getCharge()) y puntos obtenidos (getFrequentRenterPoints())
 *  Este ejemplo est� tomado del publicado en la Web: https://rootear.com/desarrollo/patron-state
 *  
 */

public class Movie 
{
	private MovieType type;

	private String title;

	public Movie(String title, MovieType type) 
	{
		this.title = title;
		this.type = type;
	}

	public MovieType getType() {
		return type;
	}

	public void setType(MovieType type) 
	{
		this.type = type;
	}

	public String getTitle() 
	{
		return title;
	}   

	public double getCharge(int daysRented)
	{
		return type.getCharge(daysRented);
	}

	public int getFrequentRenterPoints(int daysRented)
	{
		return type.getFrequentRenterPoints(daysRented);
	}
}