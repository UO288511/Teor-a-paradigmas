
public class Rental 
{
	private Movie movie;
	private int daysRented;

	public Rental(Movie m1, int daysRented) 
	{
		this.movie = m1;
		this.daysRented = daysRented;
	}

	public int getDaysRented() 
	{
		return daysRented;
	}

	public Movie getMovie() 
	{
		return movie;
	}
}