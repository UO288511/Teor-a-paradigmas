public class Test {

	public static void main(String[] args) {
		Movie m1 = new Movie("ET",Movie.CHILDRENS);
		Movie m2 = new Movie("Black Panther",Movie.NEW_RELEASE);
		Movie m3 = new Movie("El �ltimo Jedi",Movie.REGULAR);

		Customer socio1 = new Customer("Luke");
		Customer socio2 = new Customer("Elliot");
		
		socio1.addRental(new Rental(m3, 4));
		socio1.addRental(new Rental(m2, 2));
		
		socio2.addRental(new Rental(m1, 4));

		System.out.println(socio1.statement());
		System.out.println(socio2.statement());
		
		// pasando los meses
		m2.setPriceCode(Movie.REGULAR);

		// recalificaci�n
		m3.setPriceCode(Movie.CHILDRENS);
		
		System.out.println(socio1.statement());
		System.out.println(socio2.statement());
		
		
		
	}

}
