
public class CFrie implements ICommand {
	private Cocinero elCocinero;
	
	public CFrie(Cocinero c){
		this.elCocinero = c;
	}
	@Override
	public void ejecutar() {
		elCocinero.calentarAceite();
		elCocinero.freirIngredientes();
	}

}
