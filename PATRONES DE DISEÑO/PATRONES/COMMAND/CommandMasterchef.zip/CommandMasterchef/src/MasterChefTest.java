import java.util.ArrayList;
import java.util.List;

public class MasterChefTest {

	public static void main(String[] args) {

		// la plantilla de cocineros
		Cocinero pinche1 = new Cocinero("pinche1"); 
		Cocinero pinche2 = new Cocinero("pinche2"); 
		Cocinero pinche3 = new Cocinero("pinche3"); 

		// friendo huevos directamente
		System.out.println("���Cocina!!!...�un huevo frito!");
		freirHuevo(pinche1);
		

// Utilizando el patr�n COMMAND: 
		// 1� Dise�amos cada receta con el responsable de cada paso
		// 2� SOLO cuando sea necesario se ejecutar� la receta
		
				
		// Un huevo frito: el pinche 1 hace todo (prepara, frie y emplata)
		List<ICommand> recetaHuevoFrito = new ArrayList<ICommand>(); // vamos a preparar una receta de huevo frito
		// pasos de la receta
		recetaHuevoFrito.add(new CPreparaHuevo(pinche1));
		recetaHuevoFrito.add(new CFrie(pinche1));
		recetaHuevoFrito.add(new CEmplata(pinche1));
		
		// Un huevo frito 
		System.out.println("���Cocina!!!...�un huevo frito!");
		ejecutaReceta(recetaHuevoFrito);

		// dos huevos fritos
		System.out.println("���Cocina!!!...�dos huevos fritos!");
		ejecutaReceta(recetaHuevoFrito);
		ejecutaReceta(recetaHuevoFrito);

		
		
		// COMMAND: Modificando la receta
		// Tres huevos fritos: cada pinche prepara un huevo, el pinche1 los frie juntos y los emplata
		// Nos basamos en la receta original a�adiendo los dos nuevos huevos, uno por cada pinche
		List<ICommand> receta3Huevos = new ArrayList<ICommand>(recetaHuevoFrito); // copio la receta de 1 huevo
		// nuevos pasos de la receta
		receta3Huevos.add(0,new CPreparaHuevo(pinche2)); // a�adimos un segundo huevo
		receta3Huevos.add(0,new CPreparaHuevo(pinche3)); // a�adimos un tercer huevo

		//... cuando se necesite

		// tres huevos fritos "a la vez"
		System.out.println("���Cocina!!!...!tres huevos fritos�");
		ejecutaReceta(receta3Huevos);
	}

	/**
	 * M�todo directo para que un cocinero fria un huevo
	 * @param elCocinero - el cocinero responsable de la receta
	 */
	private static void freirHuevo(Cocinero elCocinero)
	{
		elCocinero.calentarAceite();
		elCocinero.cascarHuevo();
		elCocinero.salarIngrediente();
		elCocinero.freirIngredientes();
		elCocinero.emplatar();
	}
	
	/**
	 * M�todo para preparar cualquier receta que reciba (incluye tanto las acciones como los receptores)
	 * @param receta - la receta a cocinar
	 */
	private static void ejecutaReceta(List<ICommand> receta) {

		for(ICommand paso: receta)
			paso.ejecutar();

		System.out.println("Receta finalizada.\n");

	}

}
