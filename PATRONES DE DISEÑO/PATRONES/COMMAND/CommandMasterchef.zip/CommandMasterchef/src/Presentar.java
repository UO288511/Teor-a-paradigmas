
public class Presentar implements ICommand {
	private Cocinero elCocinero;
	
	public Presentar(Cocinero c){
		this.elCocinero = c;
	}
	@Override
	public void ejecutar() {
		System.out.println("Presentando el plato...");
		elCocinero.emplatar();
	}

}
