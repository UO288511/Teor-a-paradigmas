
public interface ICommand {
	void ejecutar();
}
