/**
 * Clase Cocinero, act�a como "Receptor" en el patr�n "Command"
 * @author puente
 *
 */
public class Cocinero {

	private String nombre;

	public Cocinero(String nombre){
		this.nombre = nombre;
	}
	
	// Acciones que es capaz de realizar el Receptor
	
	public void calentarAceite(){
		System.out.printf("%s: calentando aceite...\n",this.nombre);
	}

	public void cascarHuevo(){
		System.out.printf("%s: Cascando huevo...\n",this.nombre);
	}

	public void salarIngrediente(){
		System.out.printf("%s: Salando ingredientes...\n",this.nombre);
	}

	public void freirIngredientes(){
		System.out.printf("%s: Friendo todo...\n",this.nombre);
	}

	public void emplatar(){
		System.out.printf("%s: Emplatando...\n",this.nombre);
	}
}
