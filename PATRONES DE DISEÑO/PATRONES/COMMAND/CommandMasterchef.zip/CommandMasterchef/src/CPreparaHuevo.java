
public class CPreparaHuevo implements ICommand {
	private Cocinero elCocinero;
	
	public CPreparaHuevo(Cocinero c){
		this.elCocinero = c;
	}
	@Override
	public void ejecutar() {
		elCocinero.cascarHuevo();
		elCocinero.salarIngrediente();
	}

}
