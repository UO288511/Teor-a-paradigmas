
public class CEmplata implements ICommand {
	private Cocinero elCocinero;
	
	public CEmplata(Cocinero c){
		this.elCocinero = c;
	}
	@Override
	public void ejecutar() {
		elCocinero.emplatar();
	}

}
