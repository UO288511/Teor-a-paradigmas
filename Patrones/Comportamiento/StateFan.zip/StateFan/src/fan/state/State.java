package fan.state;

public abstract class State {

	abstract public void pull(StateFan v);
}
