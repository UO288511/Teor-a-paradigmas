package masterchef;

public interface ICommand {
	void perform();
}
