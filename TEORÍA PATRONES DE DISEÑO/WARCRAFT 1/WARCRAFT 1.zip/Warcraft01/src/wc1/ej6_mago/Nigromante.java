package wc1.ej6_mago;

import wc1.base.Unidad;

public class Nigromante extends Unidad {

}
