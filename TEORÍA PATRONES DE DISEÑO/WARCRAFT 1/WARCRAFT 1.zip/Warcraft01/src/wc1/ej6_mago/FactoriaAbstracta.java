package wc1.ej6_mago;

import wc1.base.Unidad;

public interface FactoriaAbstracta {

	Unidad creaInfanteria();
	Unidad creaArquero();
	Unidad creaJinete();
	Unidad creaMaquinaAsedio();
	Unidad creaMago(); // <<<<< Nuevo
}
