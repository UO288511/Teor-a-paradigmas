package wc1.ej6_mago;

import wc1.base.Unidad;
import wc1.ej5_NoMuertos.CanonDeLaPlaga;
import wc1.ej5_NoMuertos.Esqueleto;
import wc1.ej5_NoMuertos.JineteSinCabeza;
import wc1.ej5_NoMuertos.LanceroZombi;

public class FactoriaNoMuertos implements FactoriaAbstracta {

	@Override
	public Unidad creaInfanteria() {
		return new Esqueleto();
	}

	@Override
	public Unidad creaArquero() {
		return new LanceroZombi();
	}

	@Override
	public Unidad creaJinete() {
		return new JineteSinCabeza();
	}

	@Override
	public Unidad creaMaquinaAsedio() {
		return new CanonDeLaPlaga();
	}

	@Override
	public Unidad creaMago() {
		return new Nigromante();
	}
	
}
