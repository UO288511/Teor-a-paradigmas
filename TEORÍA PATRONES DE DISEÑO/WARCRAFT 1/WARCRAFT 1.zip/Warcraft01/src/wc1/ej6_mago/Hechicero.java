package wc1.ej6_mago;

import wc1.base.Unidad;

public class Hechicero extends Unidad {

}
