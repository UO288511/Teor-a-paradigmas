package wc1.ej6_mago;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// creamos una Factoria de orcos 
		FactoriaAbstracta f = new FactoriaOrcos();
		System.out.printf("El mago orco es:\n %s\n", f.creaMago());

		// creamos una Factoria de humanos
		FactoriaAbstracta f2 = new FactoriaHumanos();
		System.out.printf("El mago humano es:\n %s\n", f2.creaMago());

		// creamos una Factoria de no-muertos
		FactoriaAbstracta f3 = new FactoriaNoMuertos();
		System.out.printf("El mago no-muerto es:\n %s\n", f3.creaMago());

	}

}
