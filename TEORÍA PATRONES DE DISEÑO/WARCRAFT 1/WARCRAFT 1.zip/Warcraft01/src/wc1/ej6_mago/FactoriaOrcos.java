package wc1.ej6_mago;

import wc1.base.Catapulta;
import wc1.base.Grunt;
import wc1.base.Incursor;
import wc1.base.LanzadorDeJabalinas;
import wc1.base.Unidad;

public class FactoriaOrcos implements FactoriaAbstracta {

	@Override
	public Unidad creaInfanteria() {
		return new Grunt();
	}

	@Override
	public Unidad creaArquero() {
		return new LanzadorDeJabalinas();
	}

	@Override
	public Unidad creaJinete() {
		return new Incursor();
	}

	@Override
	public Unidad creaMaquinaAsedio() {
		return new Catapulta();
	}

	@Override
	public Unidad creaMago() {
		return new Hechicero();
	}
	
}
