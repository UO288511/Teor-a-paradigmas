package wc1.ej6_mago;

import wc1.base.Arquero;
import wc1.base.Caballero;
import wc1.base.Catapulta;
import wc1.base.SoldadoRaso;
import wc1.base.Unidad;

public class FactoriaHumanos implements FactoriaAbstracta {

	@Override
	public Unidad creaInfanteria() {
		return new SoldadoRaso();
	}

	@Override
	public Unidad creaArquero() {
		return new Arquero();
	}

	@Override
	public Unidad creaJinete() {
		return new Caballero();
	}

	@Override
	public Unidad creaMaquinaAsedio() {
		return new Catapulta();
	}

	@Override
	public Unidad creaMago() {
		return new Conjurador();
	}
	
}
