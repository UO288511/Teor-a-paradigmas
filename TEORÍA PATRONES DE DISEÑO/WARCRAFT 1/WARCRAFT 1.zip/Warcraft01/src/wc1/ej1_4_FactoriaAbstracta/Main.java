package wc1.ej1_4_FactoriaAbstracta;

import wc1.base.Unidad;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// creamos una IA de orcos 
		IAComun iaOrcos = new IAComun("orcos");
		Unidad v[] = iaOrcos.creaGrupoDeAtaque();
		
		System.out.println("Grupo de ataque orco:");
		for(Unidad u: v)
			System.out.println(u);
		
		// creamos una IA de humanos
		IAComun iaHumanos = new IAComun("humanos");
		Unidad v2[] = iaHumanos.creaGrupoDeAtaque();
		
		System.out.println("\nGrupo de ataque humano:");
		for(Unidad u: v2)
			System.out.println(u);
		
	}

}
