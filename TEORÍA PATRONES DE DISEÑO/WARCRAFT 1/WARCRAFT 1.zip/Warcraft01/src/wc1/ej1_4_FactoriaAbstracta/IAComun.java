package wc1.ej1_4_FactoriaAbstracta;

import wc1.base.Unidad;

// Inteligencia artificial de los orcos
public class IAComun {

	FactoriaAbstracta laFactoria;
	
	public IAComun(String especie){
		// Creamos la factor�a abstracta adecuada a la especie
		switch(especie) {
		case "orcos":
			laFactoria = new FactoriaOrcos();
			break;
		case "humanos":
			laFactoria = new FactoriaHumanos();	
			break;
			default:
				System.err.println("Especie desconocida: " + especie);
		}	
	}
	
	/**
	 * Generaci�n de un grupo de ataque de la I.A.
	 * @return Un grupo de ataque orco o humano dependiendo de su factor�a
	 */
	public Unidad[] creaGrupoDeAtaque()
	{
		// Array de Unidades Orcas
		Unidad[] grupoDeAtaque = new Unidad[10];
		
		// 4 x infanteria 
		for(int x = 0; x < 4; x++)
			grupoDeAtaque[x] = laFactoria.creaInfanteria();
		// 3 x arqueros
		for(int x = 4; x < 7; x++)
			grupoDeAtaque[x] = laFactoria.creaArquero();
		// 2 x jinetes 
		grupoDeAtaque[7] = laFactoria.creaJinete();
		grupoDeAtaque[8] = laFactoria.creaJinete();
		// 1 x m�quina de asedio
		grupoDeAtaque[9] = laFactoria.creaMaquinaAsedio();
		
		return grupoDeAtaque;
	}
}
