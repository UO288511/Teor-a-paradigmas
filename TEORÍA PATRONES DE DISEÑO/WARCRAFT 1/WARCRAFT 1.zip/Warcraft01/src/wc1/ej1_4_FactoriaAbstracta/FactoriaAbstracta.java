package wc1.ej1_4_FactoriaAbstracta;

import wc1.base.Unidad;

public interface FactoriaAbstracta {

	Unidad creaInfanteria();
	Unidad creaArquero();
	Unidad creaJinete();
	Unidad creaMaquinaAsedio();
}
