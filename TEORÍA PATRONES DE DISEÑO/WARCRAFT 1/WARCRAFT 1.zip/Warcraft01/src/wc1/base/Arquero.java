package wc1.base;

public class Arquero extends Unidad {

}
