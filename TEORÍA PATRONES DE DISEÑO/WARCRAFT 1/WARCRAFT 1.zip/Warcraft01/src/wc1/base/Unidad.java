package wc1.base;

public class Unidad {

	protected int hitPoints = 0;
	protected int armor = 0;
	protected int attackDamage = 0;
	protected int range = 0;
	
	//acciones
	void attack(){
	}
	void defend(){
	}
	void move(){
	}
	
}
