package wc1.base;

public class LanzadorDeJabalinas extends Unidad {

}
