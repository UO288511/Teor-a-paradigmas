package wc1.base;

public class Catapulta extends Unidad {

}
