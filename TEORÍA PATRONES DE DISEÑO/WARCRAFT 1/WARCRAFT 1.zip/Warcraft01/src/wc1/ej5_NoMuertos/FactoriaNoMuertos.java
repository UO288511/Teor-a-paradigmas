package wc1.ej5_NoMuertos;

import wc1.base.Unidad;
import wc1.ej1_4_FactoriaAbstracta.FactoriaAbstracta;

public class FactoriaNoMuertos implements FactoriaAbstracta {

	@Override
	public Unidad creaInfanteria() {
		return new Esqueleto();
	}

	@Override
	public Unidad creaArquero() {
		return new LanceroZombi();
	}

	@Override
	public Unidad creaJinete() {
		return new JineteSinCabeza();
	}

	@Override
	public Unidad creaMaquinaAsedio() {
		return new CanonDeLaPlaga();
	}
	
}
