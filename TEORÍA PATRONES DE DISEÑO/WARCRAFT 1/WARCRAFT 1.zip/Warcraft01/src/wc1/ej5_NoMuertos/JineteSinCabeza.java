package wc1.ej5_NoMuertos;

import wc1.base.Unidad;

public class JineteSinCabeza extends Unidad {

}
