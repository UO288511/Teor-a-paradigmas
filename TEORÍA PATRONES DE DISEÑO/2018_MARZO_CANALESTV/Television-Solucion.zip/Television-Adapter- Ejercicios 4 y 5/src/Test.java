/**
 * Este proyecto se corresponde con el c�digo base del enunciado
 * @author puente
 *
 */
public class Test {

	public static void main(String[] args) {

		TelePlusApp tpa = new TelePlusApp();
		tpa.muestraCanales();
		tpa.opciones();
	}





}
