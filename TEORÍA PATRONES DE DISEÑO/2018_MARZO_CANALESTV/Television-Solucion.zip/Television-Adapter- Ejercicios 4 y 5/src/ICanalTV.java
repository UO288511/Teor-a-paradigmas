/**
 * Esta Inteface no cambia
 * @author puente
 *
 */
public interface ICanalTV {
	String getNombre(); // nombre del canal
	String getTipo();	 // tipo de canal
}
