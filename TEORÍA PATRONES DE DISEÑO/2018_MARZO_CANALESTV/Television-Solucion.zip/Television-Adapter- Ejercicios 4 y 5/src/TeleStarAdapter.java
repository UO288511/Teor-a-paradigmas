/**
 * Esta clase implementa el patr�n Adapter de Objetos
 * Es necesaria esta versi�n si no queremos tener que implementar un adapter de clases por cada subclase concreta
 * En su lugar el constructor de la clase recibe el objeto que debe adaptar, pudiendo recibir cualquier objeto
 * de cualquier subclase de ChannelTeleStar (recordemos que esta es una clase abstracta luego no hay instancias de ella)
 * @author puente
 *
 */
public class TeleStarAdapter implements ICanalTV {

	private ChannelTeleStar c; // referencia al canal original adaptado
	
	public TeleStarAdapter(ChannelTeleStar ch) {
		this.c = ch;
	}

	@Override
	public String getNombre() {
		return c.getId();
	}

	@Override
	public String getTipo() {
		return c.getType();
	}

}
