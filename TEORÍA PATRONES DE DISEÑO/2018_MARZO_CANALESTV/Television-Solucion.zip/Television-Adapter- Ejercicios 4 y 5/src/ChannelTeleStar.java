/**
 * Clase abstracta que modela de forma gen�rica los canales de la empresa TeleStar
 * Esta clase NO se puede modificar
 * @author puente
 *
 */
public abstract class ChannelTeleStar{

	private String id;
	private String type;

	public ChannelTeleStar(String name, String type) {
		this.id = name;
		this.type = type;
	}

	
	public String getId() {
		return id;
	}

	
	public String getType() {
		return type;
	}


}
