/**
 * Clase que modela los canales de deportes de la empresa TeleStar
* Esta clase NO se puede modificar
 * @author puente
 *
 */
public class CSports extends ChannelTeleStar {

	public CSports(String name) {
		super(name, "sports");
	}

}
