/**
 * Esta clase no cambia
 * @author puente
 *
 */
public class CanalTelePlus implements ICanalTV {

	private String nombre;
	private String tipo;

	public CanalTelePlus(String nombre, String tipo) {
		this.nombre = nombre;
		this.tipo = tipo;
	}

	@Override
	public String getNombre() {
		return nombre;
	}

	@Override
	public String getTipo() {
		return tipo;
	}


}
