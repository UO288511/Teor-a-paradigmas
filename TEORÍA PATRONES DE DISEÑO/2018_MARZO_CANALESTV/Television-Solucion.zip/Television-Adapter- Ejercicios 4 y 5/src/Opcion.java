import java.util.ArrayList;

/**
 * La clase Opcion no es mas que una lista de canales
 * @author puente
 *
 */

public class Opcion extends ArrayList<ICanalTV>{

	/**
	 * concatena los nombres de todos los canales y los devuelve como String
	 * @return la cadena con los nombres de todos los canales de la Opcio
	 */
	public String getNombreCanales() {
		String nombres = "";
		
		// itera sobre sus propios canales
		for(ICanalTV p: this)
			nombres += p.getNombre()+" ";
		
		return nombres;
	}
	
	

}
