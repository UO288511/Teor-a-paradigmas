import java.util.ArrayList;
import java.util.List;

/**
 * Aplicaci�n de la empresa TelePlus para gestionar sus canales
 * Aqu� vamos a comprobar el efecto de manejar un canal CSeries como si fuera en realidad un ICanalTV
 * @author puente
 *
 */
public class TelePlusApp {
	private  List<ICanalTV> canales; // canales de TV de la operadora
	

	public TelePlusApp() {
		canales = new ArrayList<ICanalTV>();	

		// todos los canales de TelePlus...
		// 2 canales de series
		canales.add(new CanalTelePlus("FoxLife","series"));
		canales.add(new CanalTelePlus("AXN","series"));
		// 2 canales de m�sica
		canales.add(new CanalTelePlus("HIT-TV","m�sica"));
		canales.add(new CanalTelePlus("MTV","m�sica"));
	}
	
	public void muestraCanales() {
		System.out.println("Canales:");
		for(ICanalTV c: canales)
			System.out.println( c.getNombre() + " " + c.getTipo());
	}

	/**
	 * Nos limitamos a crear la Opcion Series y a�adir a ella el canal de series "Calle13" de la
	 *  empresa TeleStar una vez adaptado
	 */
	public void opciones() {
		
		// Opcion series: todos los canales de series
		Opcion oSeries = new Opcion();
		for(ICanalTV c: canales)
			if(c.getTipo().equals("series")) // agregamos todos los canales de series
				oSeries.add(c);	
		
		// entra en juego el Adapter
		ChannelTeleStar canalOriginal =  new CSeries("Calle 13"); // Creamos el canal original de TeleStar 
		ICanalTV canalAdaptado= new TeleStarAdapter(canalOriginal); // Creamos el objeto que lo adapta a un canal TelePlus
		oSeries.add(canalAdaptado); // a�adimos el canal adaptado a la Opci�n de Series
		
		// Tambi�n se podr�a implementar directamente como:
		// oSeries.add(new TeleStarAdapter(new CSeries("Calle 13")));
		
		// mostramos los canales de cada opcion
		System.out.println("Opcion series: " + oSeries.getNombreCanales());
		
	}
}
