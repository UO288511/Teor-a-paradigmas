/**
 * Clase que modela los canales de series de la empresa TeleStar
 * Esta clase NO se puede modificar
 * @author puente
 *
 */
public class CSeries extends ChannelTeleStar {

	public CSeries(String name) {
		super(name, "series");
	}

}
