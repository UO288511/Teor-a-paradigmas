/**
 * sin cambios
 * @author puente
 *
 */
public class CanalTelePlus implements ICanalTV{

	private String nombre;
	private String tipo;

	public CanalTelePlus(String nombre, String tipo) {
		this.nombre = nombre;
		this.tipo = tipo;
	}

	@Override
	public String getNombre() {
		return nombre;
	}

	@Override
	public String getTipo() {
		return tipo;
	}

	// Los siguientes m�todos se implementan simplemente para cumplir con la interface Opcion
	@Override
	public void eliminar(Opcion h) {}

	@Override
	public void anadir(Opcion h) {}
}
