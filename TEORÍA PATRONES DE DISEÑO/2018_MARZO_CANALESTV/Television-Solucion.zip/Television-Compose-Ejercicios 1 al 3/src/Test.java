/**
 * En este proyecto se ha aplicado el patron Composite a la hora de definir Opcion 
 * como una lista de canales y/o otras Opciones ya existente
 * @author puente
 *
 */
public class Test {

	public static void main(String[] args) {

		TelePlusApp tpa = new TelePlusApp();
		tpa.muestraCanales();
		tpa.opciones();
	}





}
