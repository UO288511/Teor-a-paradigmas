
public interface ICanalTV extends Opcion{
	String getNombre(); // nombre del canal
	String getTipo();	 // tipo de canal
}
