import java.util.ArrayList;
import java.util.List;
/**
 * Se ha adaptado la clase aplicaci�n para utilzar las opciones por medio del patr�n Composite
 * @author puente
 *
 */
public class TelePlusApp {
	private  List<ICanalTV> canales; // canales de TV de la operadora

	public TelePlusApp() {
		canales = new ArrayList<ICanalTV>();	

		// todos los canales de TelePlus...
		// 2 canales de series
		canales.add(new CanalTelePlus("FoxLife","series"));
		canales.add(new CanalTelePlus("AXN","series"));
		// 2 canales de m�sica
		canales.add(new CanalTelePlus("HIT-TV","m�sica"));
		canales.add(new CanalTelePlus("MTV","m�sica"));
	}
	
	public void muestraCanales() {
		System.out.println("Canales:");
		for(ICanalTV c: canales)
			System.out.println( c.getNombre() + " " + c.getTipo());
	}

	/** 
	 * Este es el m�todo que realmente cambia a la hora de crear las opciones y mantener sus canales
	 */
	public void opciones() {
		// Opcion m�sica: todos los canales de m�sica
		Opcion oMusica = new Compuesto();
		for(ICanalTV c: canales)
			if(c.getTipo().equals("m�sica")) // agregamos todos los canales de m�sica
				oMusica.anadir(c);

		// Opcion series: todos los canales de m�sica
		Opcion oSeries = new Compuesto();
		for(ICanalTV c: canales)
			if(c.getTipo().equals("series")) // agregamos todos los canales de series
				oSeries.anadir(c);

		// Opcion Combo: Opcion M�sica + Opcion Series
		Opcion oCombo = new Compuesto();

		// Composite: Aqu� aprovechamos el poder crear una Opcion por composici�n de otras opciones ya existentes
		oCombo.anadir(oMusica); 
		oCombo.anadir(oSeries);
		
		// mostramos los canales de cada opcion
		System.out.println("Opcion m�sica: " + oMusica.getNombre());
		System.out.println("Opcion series: " + oSeries.getNombre());
		System.out.println("Opcion combo: " + oCombo.getNombre());
		
		// Actualizando todas las opciones que incluyen m�sica con el canal "40 TV"
		ICanalTV nuevo = new CanalTelePlus("40TV","m�sica");
		oMusica.anadir(nuevo);	// A�adido a oMusica, 
								// Composite: y jer�rquicamente agregado tambi�n a oCombo
		
		// Actualizamos todas las opciones dando de baja al canal de series "FoxLife"
		oSeries.eliminar(canales.get(0)); 	// Eliminado de oSeries
											// Composite: y jer�rquicamente eliminado tambi�n de oCombo
		
		// mostramos los canales de cada opcion
		System.out.println("Canales tras a�adir 40TV y eliminar FoxLife");
		System.out.println("Opcion m�sica: " + oMusica.getNombre());
		System.out.println("Opcion series: " + oSeries.getNombre());
		System.out.println("Opcion combo: " + oCombo.getNombre());
		
	}
}
