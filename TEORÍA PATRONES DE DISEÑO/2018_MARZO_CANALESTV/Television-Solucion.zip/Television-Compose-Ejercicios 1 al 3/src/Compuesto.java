import java.util.ArrayList;
import java.util.List;

/** 
 * Nodo compuesto del patr�n Composite
 * @author puente
 *
 */
public class Compuesto implements Opcion {

	private List<Opcion> hijos; // lista de nodos hijos
	public Compuesto() {
		hijos = new ArrayList<Opcion>();
	}

	public void anadir(Opcion h) {
		hijos.add(h);
	}
	
	public void eliminar(Opcion h) {
		hijos.remove(h);
	}
	
	@Override
	public String getNombre() {
		String total = "";
		
		for(Opcion p: hijos)
			total += p.getNombre()+" ";
		
		return total;
	}
	
	

}
