/**
 * Interface Componente del patr�n Composite
 * @author puente
 *
 */
public interface Opcion {
	String getNombre(); // concatenacion de los nombres de los canales
	// metodos pensados para nodos compuestos
	void eliminar(Opcion h); // elimina un nodo hijo a un nodo compuesto
	void anadir(Opcion h); // agrega un nodo hijo a un nodo compuesto
}
