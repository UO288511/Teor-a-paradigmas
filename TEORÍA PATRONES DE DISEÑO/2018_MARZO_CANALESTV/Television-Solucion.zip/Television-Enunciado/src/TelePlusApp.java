import java.util.ArrayList;
import java.util.List;

/**
 * Aplicaci�n de la empresa TelePlus para gestionar sus canales
 * @author puente
 *
 */
public class TelePlusApp {
	private  List<ICanalTV> canales; // canales de TV de la operadora

	public TelePlusApp() {
		canales = new ArrayList<ICanalTV>();	

		// todos los canales de TelePlus...
		// 2 canales de series
		canales.add(new CanalTelePlus("FoxLife","series"));
		canales.add(new CanalTelePlus("AXN","series"));
		// 2 canales de m�sica
		canales.add(new CanalTelePlus("HIT-TV","m�sica"));
		canales.add(new CanalTelePlus("MTV","m�sica"));
	}
	
	public void muestraCanales() {
		System.out.println("Canales:");
		for(ICanalTV c: canales)
			System.out.println( c.getNombre() + " " + c.getTipo());
	}

	public void opciones() {
		// Opcion m�sica: todos los canales de m�sica
		Opcion oMusica = new Opcion();
		for(ICanalTV c: canales)
			if(c.getTipo().equals("m�sica")) // agregamos todos los canales de m�sica
				oMusica.add(c);

		// Opcion series: todos los canales de m�sica
		Opcion oSeries = new Opcion();
		for(ICanalTV c: canales)
			if(c.getTipo().equals("series")) // agregamos todos los canales de series
				oSeries.add(c);

		// Opcion Combo: Opcion M�sica + Opcion Series
		Opcion oCombo = new Opcion();
		for(ICanalTV c: oMusica)
			oCombo.add(c); // agregamos todos los canales de m�sica
		for(ICanalTV c: oSeries)
			oCombo.add(c); // agregamos todos los canales de series

		// mostramos los canales de cada opcion
		System.out.println("Opcion m�sica: " + oMusica.getNombreCanales());
		System.out.println("Opcion series: " + oSeries.getNombreCanales());
		System.out.println("Opcion combo: " + oCombo.getNombreCanales());
		
		// Actualizando todas las opciones que incluyen m�sica con el canal "40 TV"
		ICanalTV nuevo = new CanalTelePlus("40TV","m�sica");
		oMusica.add(nuevo);
		oCombo.add(nuevo);
		
		// Actualizamos todas las opicones dando de baja al canal de series "FoxLife"
		oSeries.removeIf((c)->c.getNombre().equals("FoxLife"));
		oCombo.removeIf((c)->c.getNombre().equals("FoxLife"));
		
		
		// mostramos los canales de cada opcion
		System.out.println("Canales tras a�adir 40TV y eliminar FoxLife");
		System.out.println("Opcion m�sica: " + oMusica.getNombreCanales());
		System.out.println("Opcion series: " + oSeries.getNombreCanales());
		System.out.println("Opcion combo: " + oCombo.getNombreCanales());
		
	}
}
