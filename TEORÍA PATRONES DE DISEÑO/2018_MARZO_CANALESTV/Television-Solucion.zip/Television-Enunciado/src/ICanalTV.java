/**
 * La interface ICanalTV modela el comportamiento de todos los canales que maneja TelePlus
 * @author puente
 *
 */
public interface ICanalTV {
	String getNombre(); // nombre del canal
	String getTipo();	 // tipo de canal
}
