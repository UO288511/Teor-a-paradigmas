/**
 * Clase que modela a un canal de la empresa TelePlus
 * @author puente
 *
 */
public class CanalTelePlus implements ICanalTV{

	private String nombre; // nombre del canal
	private String tipo; // tipo del canal

	public CanalTelePlus(String nombre, String tipo) {
		this.nombre = nombre;
		this.tipo = tipo;
	}

	@Override
	public String getNombre() {
		return nombre;
	}

	@Override
	public String getTipo() {
		return tipo;
	}
}
