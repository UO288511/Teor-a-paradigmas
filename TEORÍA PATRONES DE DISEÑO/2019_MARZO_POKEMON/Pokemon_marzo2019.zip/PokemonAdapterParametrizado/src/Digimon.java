
public abstract class Digimon {
	public void hit(){
		// ataca a su enemigo (equivalente a Pokemon.golpea() )
	}
	public void run(){
		// huye del combate (equivalente a Pokemon.retirarse() )
	}
	public void block(){
		// bloquea el siguiente ataque de su enemigo (equivalente a Pokemon.defender() )
	}
}

