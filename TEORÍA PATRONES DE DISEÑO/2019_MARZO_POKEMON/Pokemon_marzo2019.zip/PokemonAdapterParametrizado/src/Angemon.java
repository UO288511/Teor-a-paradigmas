
public class Angemon extends Digimon {

}
