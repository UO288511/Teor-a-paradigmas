/**
 * Clase que adapta por composici�n cualquier Digimon a Pokemon
 * @author puente
 *
 */
public class DigimonAdaptado extends Pokemon {
	private Digimon dig; // digimon adaptado
	
	/**
	 * Constructor parametrizado
	 * @param _dig - digimon a adaptar
	 */
	public DigimonAdaptado(Digimon _dig){
		dig = _dig;
	}

	/**
	 * Operacion golpea de Pokemon basada en el hit() de Digimon
	 */
	@Override
	public void golpea() {
		dig.hit();
	}

	/**
	 * Operacion retirate de Pokemon basada en el run() de Digimon
	 */
	@Override
	public void retirate() {
		dig.run();
	}

	/**
	 * Operacion defender de Pokemon basada en el block() de Digimon
	 */
	@Override
	public void defender() {
		dig.block();
	}
}
