
public class EntrenadorPokemon {
	private Pokemon p1; // primer pokemon de su equipo
	private Pokemon p2; // segundo pokemon de su equipo
	
	/**
	 * Constructor por defecto que genera un equipo con un Agumon y un Angemon
	 */
	public EntrenadorPokemon(){
		p1 = new DigimonAdaptado(new Agumon()); // creamos el Digimon y lo adaptamos
		p2 = new DigimonAdaptado(new Angemon()); // creamos el Digimon y lo adaptamos
	}
	
	// El resto de c�digo no se ve modificado
	
	public void planDefensivo(){
		p1.defender();
		p2.defender();
	}

	public void plandOfensivo(){
		p1.golpea();
		p2.golpea();
		p1.golpea();
		p2.golpea();
	}
}
