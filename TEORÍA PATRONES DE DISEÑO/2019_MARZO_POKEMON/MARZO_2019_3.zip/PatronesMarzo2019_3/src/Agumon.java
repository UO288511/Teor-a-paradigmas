
public class Agumon extends Digimon {

}
