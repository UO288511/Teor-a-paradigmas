
public class EntrenadorPokemon {
	private Pokemon p1;
	private Pokemon p2;
	
	/**
	 * Constructor por defecto, crea un equipo de Pikachu y Charmander
	 */
	public EntrenadorPokemon(){
		p1 = Pokemon.creaPokemon("pikachu");
		p2 = Pokemon.creaPokemon("charmander");
	}
	
	/** 
	 * Constructor parametrizado
	 * @param tipo1 - tipo del pokemon1
	 * @param tipo2 - tipo del pokemon2
	 */
	public EntrenadorPokemon(String tipo1, String tipo2){
		p1 = Pokemon.creaPokemon(tipo1);
		p2 = Pokemon.creaPokemon(tipo2);
	}

	// El resto de c�digo no se ve modificado
	
	public void planDefensivo(){
		p1.defender();
		p2.defender();
	}

	public void plandOfensivo(){
		p1.golpea();
		p2.golpea();
		p1.golpea();
		p2.golpea();
	}
}
