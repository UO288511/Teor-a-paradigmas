
public abstract class Pokemon {
	public void golpea(){
		// golpea a alg�n pokemon enemigo a tiro
	}
	public void retirate(){
		// vuelve a su pokeball
	}
	public void defender(){
		// el pokemon se concentra para recibir menos da�o en el siguiente ataque
	}
}
