/**
 * Este tipo de entrenador solo trabaja con Pikachus
 * @author puente
 *
 */
public class EntrenadorPikachu extends EntrenadorPokemon {

	public EntrenadorPikachu() {

	}
	/**
	 *  El m�todo factoria solo retorna pokemons del tipo Pikachu
	 *  
	 *  @return el nuevo objeto Pikachu creado
	 */
	@Override
	public Pokemon nuevoPokemon() {
		return new Pikachu(); 
	}

}
