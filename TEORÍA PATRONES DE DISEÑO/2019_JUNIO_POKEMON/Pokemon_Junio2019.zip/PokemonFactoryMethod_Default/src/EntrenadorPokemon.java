
public abstract class EntrenadorPokemon {
	private Pokemon p1; // primer pokemon de su equipo
	private Pokemon p2; // segundo pokemon de su equipo
	
	
	public EntrenadorPokemon(){
		// Aplicando el patr�n FactoryMethod los pokemons se generan con el m�todo factoria
		p1 = nuevoPokemon();  
		p2 = nuevoPokemon();
	}
	
	public void planDefensivo(){
		p1.defender();
		p2.defender();
	}

	public void plandOfensivo(){
		p1.golpea();
		p2.golpea();
		p1.golpea();
		p2.golpea();
	}
	
	public abstract Pokemon nuevoPokemon(); // Cada tipo de entrenador definir� el tipo de pokemon que genera y entrena
}
