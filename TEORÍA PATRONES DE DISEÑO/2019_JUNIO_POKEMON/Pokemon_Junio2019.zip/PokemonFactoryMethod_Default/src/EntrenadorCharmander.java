/**
 * Este tipo de entrenador solo trabaja con Charmanders
 * @author puente
 *
 */
public class EntrenadorCharmander extends EntrenadorPokemon {

	public EntrenadorCharmander() {

	}
	/**
	 *  El m�todo factoria solo retorna pokemons del tipo Charmander
	 *  
	 *  @return el nuevo objeto Charmander creado
	 */
	@Override
	public Pokemon nuevoPokemon() {
		return new Charmander(); 
	}

}