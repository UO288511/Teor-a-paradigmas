
public class EntrenadorPokemon {
	// pokemons del entrenador
	private Pokemon p1;
	private Pokemon p2;
	
	// atributo que contendr� el plan defensivo
	private ICommand planDefensivo[];

	// atributo que contendr� el plan ofensivo
	private ICommand[] planOfensivo;
	
	public EntrenadorPokemon(){

		// creamos los pokemons
		p1 = new Pikachu();
		p2 = new Charmander();
	
		// creamos el plan defensivo
		planDefensivo =  new ICommand[2]; // son dos acciones...
		planDefensivo[0] = new OrdenDefender(p1); // 1- p1 defiende
		planDefensivo[1] = new OrdenDefender(p2); // 2- p2 defiende
		
		// creamos el plan ofensivo
		planOfensivo =  new ICommand[4]; // son 4 acciones...
		planOfensivo[0] = new OrdenGolpea(p1); // 1- p1 golpea
		planOfensivo[1] = new OrdenGolpea(p2); // 2- p2 golpea
		planOfensivo[2] = new OrdenGolpea(p1); // 3- p1 golpea
		planOfensivo[3] = new OrdenGolpea(p2); // 4- p2 golpea
	}
	
	public void planDefensivo(){
	
	}

	public void plandOfensivo(){
		// ejecuta el plan ofensivo
		for(ICommand o: planOfensivo)
			o.ejecutar();
	}
}
