
public class OrdenGolpea implements ICommand {

	// receptor que ejecuta la acci�n
	private Pokemon receptor;
	
	public OrdenGolpea(Pokemon p) {
		this.receptor = p;
	}

	@Override
	public void ejecutar() {
		receptor.golpea();
	}

}
