
public class Charmander extends Pokemon {

}
