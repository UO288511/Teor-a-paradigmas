
public class OrdenDefender implements ICommand {

	// receptor que ejecuta la acci�n
	private Pokemon receptor;
	
	public OrdenDefender(Pokemon p) {
		this.receptor = p;
	}

	@Override
	public void ejecutar() {
		receptor.defender();
	}

}
