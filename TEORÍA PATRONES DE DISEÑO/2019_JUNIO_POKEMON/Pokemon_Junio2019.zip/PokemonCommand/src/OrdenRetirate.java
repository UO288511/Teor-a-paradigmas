
public class OrdenRetirate implements ICommand {

	// receptor que ejecuta la acci�n
	private Pokemon receptor;
	
	public OrdenRetirate(Pokemon p) {
		this.receptor = p;
	}

	@Override
	public void ejecutar() {
		receptor.retirate();
	}

}
