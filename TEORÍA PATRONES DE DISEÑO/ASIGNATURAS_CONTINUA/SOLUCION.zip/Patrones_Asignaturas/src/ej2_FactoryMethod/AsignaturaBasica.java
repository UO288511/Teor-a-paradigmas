package ej2_FactoryMethod;

public class AsignaturaBasica extends Asignatura {

	public AsignaturaBasica() {

		// TODO Auto-generated constructor stub
	}

}
