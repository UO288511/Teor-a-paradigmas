package ej2_FactoryMethod;

public class AsignaturaOptativa extends Asignatura {

	public AsignaturaOptativa() {
		
		// TODO Auto-generated constructor stub
	}

}
