package ej2_FactoryMethod;

public class GeneradorPlanEstudios {

	public GeneradorPlanEstudios() {}
	
	public static Asignatura operacionYTipoFactoryMethod(String tipo, String nombre, int creditos) {
		Asignatura a = null;
		a = Asignatura.factoria(tipo, creditos, nombre);
		a.setNombre(nombre);
		a.setCreditos(creditos);
		return a;
	}
	
	public static void main(String[] args) {
		Asignatura a = operacionYTipoFactoryMethod("basica", "Ondas", 6);
		System.out.printf("Asignatura %s -> %s con %d creditos",
				a.getClass().getName(), a.getNombre(), a.getCreditos());
		
	}
}
