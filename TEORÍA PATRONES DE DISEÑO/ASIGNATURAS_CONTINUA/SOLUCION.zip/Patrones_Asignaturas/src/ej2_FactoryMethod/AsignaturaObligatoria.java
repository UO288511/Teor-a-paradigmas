package ej2_FactoryMethod;

public class AsignaturaObligatoria extends Asignatura {

	public AsignaturaObligatoria() {
		// TODO Auto-generated constructor stub
	}

}
