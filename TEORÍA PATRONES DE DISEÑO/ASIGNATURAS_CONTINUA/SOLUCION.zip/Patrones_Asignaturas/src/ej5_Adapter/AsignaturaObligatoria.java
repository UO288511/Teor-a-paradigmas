package ej5_Adapter;

public class AsignaturaObligatoria extends Asignatura {

	public AsignaturaObligatoria() {
		// TODO Auto-generated constructor stub
	}

}
