package ej5_Adapter;

public class AsignaturaOptativa extends Asignatura {

	public AsignaturaOptativa() {
		
		// TODO Auto-generated constructor stub
	}

}
