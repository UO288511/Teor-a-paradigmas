package ej5_Adapter;

public class AdaptadorPracticaEmpresa extends Asignatura {

	private PracticaEmpresa pe = new PracticaEmpresa();

	public AdaptadorPracticaEmpresa() { }
	
	public String getNombre() { return "Practica Empresa"; }
	public void setNombre(String s) { }

	public int getCreditos() { return super.getCreditos() * 6; }
	public void setCreditos(int c) { this.pe.setTotalHoras(c); }
	
	
}
