package ej5_Adapter;

public class PracticaEmpresa {

	private int totalHoras;
	
	public PracticaEmpresa() {}
	
	public int getTotalHoras() { return this.totalHoras; }
	public void setTotalHoras(int h) { this.totalHoras = h; }
	
	
}
