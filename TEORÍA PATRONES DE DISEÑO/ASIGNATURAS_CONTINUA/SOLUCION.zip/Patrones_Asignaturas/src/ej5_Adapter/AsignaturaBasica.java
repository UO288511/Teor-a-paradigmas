package ej5_Adapter;

public class AsignaturaBasica extends Asignatura {

	public AsignaturaBasica() {

		// TODO Auto-generated constructor stub
	}

}
