package ej5_Adapter;

public abstract class Asignatura {

	private int creditos; private String nombre;
	
	public Asignatura() {

	}

	public int getCreditos() {
		return creditos;
	}

	public void setCreditos(int creditos) {
		this.creditos = creditos;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public static Asignatura factoria(String tipo) {
		switch(tipo) {
		case "basica" : return new AsignaturaBasica();
		case "optativa": return new AsignaturaOptativa();
		case "obligatoria": return new AsignaturaObligatoria();
		case "practica" : return new AdaptadorPracticaEmpresa();
		default: return null;
		}
	}
}
