package ej6_Composite;

public class Cliente {
	public static void main(String[] args) {
		creaYMuestra("supra");
	}
	
	private static void creaYMuestra(String tipo) {
		Bus b = Bus.factoria(tipo, "01", 200, 203.32);
		System.out.printf("Bus %s con %d km y %f de gas\n", 
				b.getId(), b.getKm(), b.getGas());
	}
	
}
