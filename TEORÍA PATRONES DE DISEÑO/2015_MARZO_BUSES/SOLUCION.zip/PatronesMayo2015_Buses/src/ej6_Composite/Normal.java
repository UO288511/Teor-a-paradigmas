package ej6_Composite;

public class Normal extends Bus {

	public Normal(String id, long km, double g) {
		super(id, km, g);
	}

}
