package ej6_Composite;

public class Bus implements MetaBus {
	protected String id;
	protected long km;
	protected double gas;
	
	public Bus(String id, long km, double g) {
		this.id = id;
		this.km = km;
		this.gas = g;
	}
	
	public String getId() {
		return id;
	}
	public long getKm() {
		return km;
	}
	public double getGas() {
		return gas;
	}
	
	public static Bus factoria(String tipo, String id, long km,
			double gas) {
		switch(tipo) {
		case "supra" : return new Supra(id,km,gas);
		case "normal": return new Normal(id,km,gas);
		default: return null;
		}
	}
	
}
