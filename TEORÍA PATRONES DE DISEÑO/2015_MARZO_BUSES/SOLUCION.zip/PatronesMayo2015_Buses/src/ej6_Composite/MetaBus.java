package ej6_Composite;

public interface MetaBus {

	public String getId();
	public long getKm();
	public double getGas();
	
}
