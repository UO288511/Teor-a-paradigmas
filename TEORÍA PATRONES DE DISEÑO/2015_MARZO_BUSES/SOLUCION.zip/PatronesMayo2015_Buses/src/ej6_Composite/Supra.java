package ej6_Composite;

public class Supra extends Bus{

	public Supra(String id, long km, double g) {
		super(id, km, g);
	}

}
