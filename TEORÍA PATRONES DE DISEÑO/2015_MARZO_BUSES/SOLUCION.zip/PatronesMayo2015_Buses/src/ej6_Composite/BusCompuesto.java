package ej6_Composite;

import java.util.List;

public class BusCompuesto implements MetaBus {

	private String nombre = "";
	private List<MetaBus> hijos;
	
	public BusCompuesto(String nombre) {
		this.nombre = nombre;
	}
	
	@Override
	public String getId() {
		// TODO Auto-generated method stub
		return nombre;
	}

	@Override
	public long getKm() {
		// TODO Auto-generated method stub
		long total = 0;
		for(MetaBus b: hijos) {
			total += b.getKm();
		}
		return total;
	}

	@Override
	public double getGas() {
		// TODO Auto-generated method stub
		double total = 0;
		for(MetaBus b: hijos) {
			total += b.getGas();
		}
		return total;
	}
	
	public void add(MetaBus b) {
		hijos.add(b);
	}
	
	public void del(int pos) {
		hijos.remove(pos);
	}
	
	
}
