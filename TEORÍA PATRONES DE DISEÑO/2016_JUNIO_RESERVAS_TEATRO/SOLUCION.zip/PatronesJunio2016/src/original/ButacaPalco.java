package original;

public class ButacaPalco extends ButacaTeatro{

	private int dia, hora, sala, fila, butaca;
	private String pelicula;
	
	public ButacaPalco() { }
}
