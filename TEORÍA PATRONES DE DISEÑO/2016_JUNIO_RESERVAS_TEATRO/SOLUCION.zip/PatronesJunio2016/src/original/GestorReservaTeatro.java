package original;

public class GestorReservaTeatro {

	public GestorReservaTeatro() { }
	
	public ButacaTeatro creaReservaButacaPatio() { 
		return new ButacaPatio();
	}
	
	public ButacaTeatro creaReservaButacaPalco() {
		return new ButacaPalco();
	}
	
	public ButacaTeatro creaReservaButacaEntresuelo() {
		return new ButacaEntresuelo();
	}
	
	
}
