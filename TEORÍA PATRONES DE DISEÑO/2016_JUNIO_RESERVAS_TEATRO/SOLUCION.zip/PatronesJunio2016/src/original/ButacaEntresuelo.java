package original;

public class ButacaEntresuelo extends ButacaTeatro {

	private int dia, hora, sala, fila, butaca;
	private String pelicula;
	
	public ButacaEntresuelo() { }
}
