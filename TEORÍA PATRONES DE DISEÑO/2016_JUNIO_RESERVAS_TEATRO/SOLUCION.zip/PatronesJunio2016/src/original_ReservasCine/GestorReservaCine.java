package original_ReservasCine;

public class GestorReservaCine {

	public GestorReservaCine() { }
	
	public Reserva creaReserva() {
		Reserva a = null;
		return a;
	}
}
