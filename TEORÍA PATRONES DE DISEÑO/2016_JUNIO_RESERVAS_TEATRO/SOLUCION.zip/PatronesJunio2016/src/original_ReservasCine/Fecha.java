package original_ReservasCine;

public class Fecha {

	private int dia, hora;
	
	Fecha() { }
}
