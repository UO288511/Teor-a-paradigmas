package original_ReservasCine;

public class Reserva {

	private int sala, fila, butaca;
	private String titulo;
	private Fecha sesion;
	
	public Reserva() { }
}
