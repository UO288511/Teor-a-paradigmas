package ej2_FactoryMethod;

public class GestorReservaTeatro {

	public GestorReservaTeatro() { }
	
	public ButacaTeatro creaButaca(String tipo) {
		ButacaTeatro b = ButacaTeatro.creaButaca(tipo);
		return b;
	}
	
	
}
