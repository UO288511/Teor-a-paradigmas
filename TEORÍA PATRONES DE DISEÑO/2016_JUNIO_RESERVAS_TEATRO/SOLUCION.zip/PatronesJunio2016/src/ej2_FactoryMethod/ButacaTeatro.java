package ej2_FactoryMethod;

public abstract class ButacaTeatro {

	private int dia, hora, sala, fila, butaca;
	private String pelicula;
	
	public ButacaTeatro() {}
	
	public static ButacaTeatro creaButaca(String tipo) {
		switch(tipo) {
		case "patio": return new ButacaPatio();
		case "palco": return new ButacaPalco();
		case "entresuelo": return new ButacaEntresuelo();
		default: return null;
		}
	}
}
