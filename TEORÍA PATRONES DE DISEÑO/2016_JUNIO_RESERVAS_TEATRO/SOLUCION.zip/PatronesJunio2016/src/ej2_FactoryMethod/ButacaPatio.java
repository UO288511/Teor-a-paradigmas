package ej2_FactoryMethod;

public class ButacaPatio extends ButacaTeatro {


	private int dia, hora, sala, fila, butaca;
	private String pelicula;
	
	public ButacaPatio() { }
}
