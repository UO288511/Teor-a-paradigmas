package ej4_AdapterObjetos;

public class Reserva {

	private int sala, fila, butaca;
	private String titulo;
	private Fecha sesion;
	
	Reserva() { }

	public Fecha getSesion() {
		return sesion;
	}

	public void setSesion(Fecha sesion) {
		this.sesion = sesion;
	}

	public int getSala() {
		return sala;
	}

	public void setSala(int sala) {
		this.sala = sala;
	}

	public int getFila() {
		return fila;
	}

	public void setFila(int fila) {
		this.fila = fila;
	}

	public int getButaca() {
		return butaca;
	}

	public void setButaca(int butaca) {
		this.butaca = butaca;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	
	
}
