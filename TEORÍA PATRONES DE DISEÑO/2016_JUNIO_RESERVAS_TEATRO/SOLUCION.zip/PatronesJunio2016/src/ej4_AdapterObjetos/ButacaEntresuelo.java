package ej4_AdapterObjetos;

public class ButacaEntresuelo extends ButacaTeatro {


	
	public ButacaEntresuelo() { }
}
