package ej4_AdapterObjetos;

public abstract class ButacaTeatro {

	private int dia, hora, sala, fila, butaca;
	private String pelicula;

}
