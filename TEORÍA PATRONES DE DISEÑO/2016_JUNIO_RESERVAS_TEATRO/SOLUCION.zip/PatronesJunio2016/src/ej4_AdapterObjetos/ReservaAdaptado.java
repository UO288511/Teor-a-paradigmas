package ej4_AdapterObjetos;

public class ReservaAdaptado extends ButacaTeatro {

	private Reserva r;
	
	ReservaAdaptado() { }
	
	public int getDia() { return this.r.getSesion().getDia(); }
	public void setDia(int d) { this.r.getSesion().setDia(d); }
	
	public int getHora() { return this.r.getSesion().getHora(); }
	public void setHora(int h) { this.r.getSesion().setHora(h); }
	
	public int getSala() { return this.r.getSala(); }
	public void setSala(int s) { this.r.setSala(s); }
	
	public String getPelicula() { return this.r.getTitulo(); }
	public void setPelicula(String s) {this.r.setTitulo(s); }
	
	public int getFila() { return this.r.getFila(); }
	public void setFila(int f) {this.r.setFila(f); }
	
	public int getButaca() { return this.r.getButaca(); }
	public void setButaca(int b) { this.r.setButaca(b); }
	
}
