package ej4_AdapterObjetos;

public class ButacaPalco extends ButacaTeatro{


	
	public ButacaPalco() { }
}
