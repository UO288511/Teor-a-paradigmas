package ej4_AdapterObjetos;

public class ButacaPatio extends ButacaTeatro {


	
	public ButacaPatio() { }
}
