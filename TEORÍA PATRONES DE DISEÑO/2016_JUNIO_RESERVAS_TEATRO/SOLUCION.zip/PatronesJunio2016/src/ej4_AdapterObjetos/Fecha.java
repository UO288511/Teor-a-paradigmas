package ej4_AdapterObjetos;

public class Fecha {

	private int dia, hora;
	
	Fecha() { }
	
	public int getDia() { return dia; }
	public void setDia(int d) { dia = d; }
	
	public int getHora() { return hora; }
	public void setHora(int h) { hora = h; }
}
