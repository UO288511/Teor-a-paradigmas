package ej3_Singleton;

public class WebDataBase {

	private int totalConsultas;
	
	public WebDataBase() {
		totalConsultas = 0;
	}
	
	public int getTotalConsultas() {
		return this.totalConsultas;
	}
	
	String[] consulta(String criterios) {
		String[] retorno = null;
		totalConsultas++;
		return retorno;
	}
}
