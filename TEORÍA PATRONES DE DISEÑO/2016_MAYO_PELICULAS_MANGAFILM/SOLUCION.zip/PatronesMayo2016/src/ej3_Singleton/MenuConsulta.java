package ej3_Singleton;

public class MenuConsulta {

	public MenuConsulta() { }
	
	
	public void buscarPelicultas(String criterios) {
		WebDataBaseSingleton wdb = WebDataBaseSingleton.getInstance();
		wdb.consulta(criterios);
	}
}
