package ej3_Singleton;

public class WebDataBaseSingleton {

	private static WebDataBaseSingleton _instance = null;
	private int totalConsultas; 
	
	
	public static WebDataBaseSingleton getInstance() {
		if(_instance == null) {
			_instance = new WebDataBaseSingleton();
		}
		return _instance;
	}
	
	private WebDataBaseSingleton() {
		totalConsultas = 0;
	}
	
	public int getTotalConsultas() { return this.totalConsultas; }
	
	private WebDataBase wdb;
	
	protected void consulta(String criterios) {
		for(String titulo: wdb.consulta(criterios)) {
			System.out.println(titulo);
		}
	}
}
