package ej2_AdapterClases;

public class MangaFilm {
	private String nombre_peli;
	private String[] protagonistas, resto_personajes;
	
	public MangaFilm(String np, String[] p, String[] rp) {
		this.nombre_peli = np;
		this.protagonistas = p;
		this.resto_personajes = rp;
	}

	protected String getNombre_peli() {
		return nombre_peli;
	}

	protected String[] getProtagonistas() {
		return protagonistas;
	}

	protected String[] getResto_personajes() {
		return resto_personajes;
	}
	
	
}
