package ej2_AdapterClases;

public interface IPelicula {

	public String getTitulo();
	public String getGenero();
	public String[] getCasting();
}
