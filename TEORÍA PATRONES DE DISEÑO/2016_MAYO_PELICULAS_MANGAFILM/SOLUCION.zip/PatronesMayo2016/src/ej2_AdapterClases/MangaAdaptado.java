package ej2_AdapterClases;

public class MangaAdaptado extends MangaFilm implements IPelicula {

	public MangaAdaptado(String np, String[] p, String[] rp) {
		super(np, p, rp);
	}

	@Override
	public String getTitulo() {
		// TODO Auto-generated method stub
		return super.getNombre_peli();
	}

	@Override
	public String getGenero() {
		// TODO Auto-generated method stub
		return "MangaFilm";
	}

	@Override
	public String[] getCasting() {
		// TODO Auto-generated method stub
		String[] casting = 
				new String[super.getProtagonistas().length + 
				           super.getResto_personajes().length];
		System.arraycopy(super.getProtagonistas(), 0,
				casting, 0, super.getProtagonistas().length);
		System.arraycopy(super.getResto_personajes(), 0,
				casting, super.getProtagonistas().length,
				super.getResto_personajes().length);
		return casting;
	}

	


	
}
