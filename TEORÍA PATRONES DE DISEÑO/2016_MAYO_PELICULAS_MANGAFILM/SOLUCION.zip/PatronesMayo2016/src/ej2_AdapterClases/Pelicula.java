package ej2_AdapterClases;

public class Pelicula implements IPelicula {
	private String titulo, genero;
	private String[] casting;
	
	public Pelicula(String t, String g, String[] c) {
		this.titulo = t;
		this.genero = g;
		this.casting = c;
	}
	
	public String getTitulo() {
		return titulo;
	}
	public String getGenero() {
		return genero;
	}
	public String[] getCasting() {
		return casting;
	}
	
	
}
