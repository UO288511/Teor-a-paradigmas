package ej2_AdapterClases;

public class AplicacionCliente {

	public static void main(String[] args) {
		Pelicula p = new Pelicula("", "", null);
	}
	
	public AplicacionCliente() { }
	
	public IPelicula seleccionPeliculas() {
		return null;
	}
}
