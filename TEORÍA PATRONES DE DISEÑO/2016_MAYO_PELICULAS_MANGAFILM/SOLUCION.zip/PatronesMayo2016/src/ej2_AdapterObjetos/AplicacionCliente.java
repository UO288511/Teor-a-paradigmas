package ej2_AdapterObjetos;

public class AplicacionCliente {

	public static void main(String[] args) {
		
	}
	
	public AplicacionCliente() { }
	
	public Pelicula seleccionPeliculas() {
		return null;
	}
}
