package ej2_AdapterObjetos;

public class MangaAdaptado extends Pelicula {

	private MangaFilm mf = null;

	public MangaAdaptado(String t, String g, String[] c, MangaFilm mf) {
		super(t, g, c);
		this.mf = mf;
	}	
	
	public String getTitulo() {
		return mf.getNombre_peli();
	}
	
	public String getGenero() { return "MangaFilm"; }
	
	public String[] getCasting() {
		// TODO Auto-generated method stub
		String[] casting = 
				new String[mf.getProtagonistas().length +
				           mf.getResto_personajes().length];
		System.arraycopy(mf.getProtagonistas(), 0,
				casting, 0, mf.getProtagonistas().length);
		System.arraycopy(mf.getResto_personajes(), 0,
				casting, mf.getProtagonistas().length,
				mf.getResto_personajes().length);
		return casting;
	}
	

}
