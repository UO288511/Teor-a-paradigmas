package wc2.ej_4_6_singleton;

import wc2.base.Unidad;

public class C2 {
	void m2(){
		// variable Unidad que contendr� el drag�n
		Unidad d;
		// obtenemos el drag�n
		d = DragonAdaptadoSingleton.getDragon();
		// lo utilizamos para moverlo
		d.move();
	}
}
