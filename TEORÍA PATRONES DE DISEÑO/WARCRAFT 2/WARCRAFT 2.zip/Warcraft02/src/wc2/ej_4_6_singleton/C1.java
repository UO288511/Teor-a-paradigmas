package wc2.ej_4_6_singleton;

import wc2.base.Unidad;

public class C1 {
	void m1(){
		// variable Unidad que contendr� el drag�n
		Unidad d;
		// obtenemos el drag�n
		d = DragonAdaptadoSingleton.getDragon();
		// lo utilizamos para atacar
		d.attack();
	}
}
