package wc2.ej_4_6_singleton;

import wc2.base.Dragon;
import wc2.base.Unidad;

public class DragonAdaptadoSingleton extends Unidad{
	// La instancia privada de drag�n
	private static DragonAdaptadoSingleton elDragon = new DragonAdaptadoSingleton();
	// El constructor pasa a ser privado para que no se puedan crear objetos
	// fuera de la clase
	private DragonAdaptadoSingleton(){
	}
	// �nico m�todo de clase p�blico que permite acceder a la instancia real
	public static DragonAdaptadoSingleton getDragon(){
		return elDragon;
	}
	/* Aqu� ir�an las propiedades y operaciones de DragonAdaptado */

	private Dragon dragonOriginal = new Dragon();
	//acciones
	/**
	 * attack - un drag�n atacar� volando y lanzando fuego desde el aire
	 */
	public void attack(){
		this.dragonOriginal.vuela();
		this.dragonOriginal.lanzaFuego();
	}
	/**
	 * defend - un drag�n se defender� "atacando"
	 */
	public void defend(){
		attack();
	}
	/**
	 * move - un drag�n se mueve volando y luego aterrizando
	 */
	public void move(){
		this.dragonOriginal.vuela();
		this.dragonOriginal.aterriza();
	}

}