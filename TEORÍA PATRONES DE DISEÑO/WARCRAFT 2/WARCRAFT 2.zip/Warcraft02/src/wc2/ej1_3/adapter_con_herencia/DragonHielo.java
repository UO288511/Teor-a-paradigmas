package wc2.ej1_3.adapter_con_herencia;

import wc2.base.Dragon;

public class DragonHielo extends Dragon {
	@Override
	public void lanzaFuego() {
		System.out.println("Lanzo hielo");
	}
}
