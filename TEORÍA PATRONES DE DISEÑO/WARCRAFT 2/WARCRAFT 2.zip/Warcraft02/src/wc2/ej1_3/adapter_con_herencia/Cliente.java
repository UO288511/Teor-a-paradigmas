package wc2.ej1_3.adapter_con_herencia;

import wc2.base.Unidad;

public class Cliente {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// creamos un vector de unidades formado por 3 dragones: uno de fuego otro de hielo y otro Igneo
		Unidad v[] = { 
				new DragonAdaptado(), 
				new DragonAdaptado(new DragonHielo()), 
				new DragonAdaptado(new DragonAcido())
				};
		
		// que ataquen todos como unidades
		for(Unidad x: v)
			x.attack();
	}

}
