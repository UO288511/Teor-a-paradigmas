package wc2.ej1_3_adapter;

import wc2.base.Dragon;
import wc2.base.Unidad;

public class DragonAdaptado extends Unidad {
	// Dragon por composici�n (campo privado)
	private Dragon dragonOriginal = new Dragon();
	//acciones
	/**
	 * attack - un drag�n atacar� volando y lanzando fuego desde el aire
	 */
	public void attack(){
		this.dragonOriginal.vuela();
		this.dragonOriginal.lanzaFuego();
	}
	/**
	 * defend - un drag�n se defender� "atacando"
	 */
	public void defend(){
		attack();
	}
	/**
	 * move - un drag�n se mueve volando y luego aterrizando
	 */
	public void move(){
		this.dragonOriginal.vuela();
		this.dragonOriginal.aterriza();
	}
}