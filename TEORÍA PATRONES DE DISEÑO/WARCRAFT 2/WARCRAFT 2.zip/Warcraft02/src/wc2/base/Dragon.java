package wc2.base;

public class Dragon {
	public void aterriza() {}
	public void vuela() {}
	public void lanzaFuego() {
		System.out.println("Lanzo fuego");
	}
}
