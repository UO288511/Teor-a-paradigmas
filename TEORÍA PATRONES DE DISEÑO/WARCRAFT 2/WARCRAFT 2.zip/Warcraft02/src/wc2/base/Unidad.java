package wc2.base;


public class Unidad {

	protected int hitPoints = 0;
	protected int armor = 0;
	protected int attackDamage = 0;
	protected int range = 0;
	
	//acciones
	public void attack(){
	}
	public void defend(){
	}
	public void move(){
	}
	
}
