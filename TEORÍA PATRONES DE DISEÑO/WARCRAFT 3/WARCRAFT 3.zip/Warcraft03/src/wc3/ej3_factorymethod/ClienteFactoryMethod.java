package wc3.ej3_factorymethod;

public class ClienteFactoryMethod{
	public void creaYLanzaPirata(int tipo){
		// se crea el tipo de pirata escogido
		Pirata p = Pirata.metodoFactoria(tipo);
		// acciones comunes a todo pirata
		p.move(); 
		p.move();
		p.attack();
		p.defend();
	}
}