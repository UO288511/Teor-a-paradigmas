package wc3.base;


public abstract class Unidad {
	//acciones
	public abstract void attack();
	public abstract void defend();
	public abstract void move();
	
}
