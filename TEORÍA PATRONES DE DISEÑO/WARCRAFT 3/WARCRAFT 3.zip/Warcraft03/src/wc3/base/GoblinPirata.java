package wc3.base;

public class GoblinPirata {
	public void navega() {}
	public void abordar() {}
	public void esquivar() {}
}
