package wc3.base;

public class CorsarioIngles {
	public void avanza() { }
	public void disparar() { }
	public void bloquearEnemigo() { }
}
