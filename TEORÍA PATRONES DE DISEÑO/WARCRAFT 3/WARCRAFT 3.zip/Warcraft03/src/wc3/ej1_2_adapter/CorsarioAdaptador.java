package wc3.ej1_2_adapter;

import wc3.base.CorsarioIngles;
import wc3.base.Unidad;

public class CorsarioAdaptador extends Unidad{
	private CorsarioIngles ci;  // objeto adaptado
	
	public CorsarioAdaptador(){
		ci = new CorsarioIngles();
	}
	
	@Override
	public void attack() {
		ci.disparar();
	}
	
	@Override
	public void defend() {
		ci.bloquearEnemigo();
	}
	
	@Override
	public void move() {
		ci.avanza();
	}

}
