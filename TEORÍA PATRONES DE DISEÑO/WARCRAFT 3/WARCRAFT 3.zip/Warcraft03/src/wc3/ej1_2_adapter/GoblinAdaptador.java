package wc3.ej1_2_adapter;

import wc3.base.GoblinPirata;
import wc3.base.Unidad;

public class GoblinAdaptador extends Unidad{
	private GoblinPirata gp;  // objeto adaptado
	
	public GoblinAdaptador(){
		gp = new GoblinPirata();
	}
	
	@Override
	public void attack() {
		gp.abordar();
	}
	
	@Override
	public void defend() {
		gp.esquivar();
	}
	
	@Override
	public void move() {
		gp.navega();
	}

}
