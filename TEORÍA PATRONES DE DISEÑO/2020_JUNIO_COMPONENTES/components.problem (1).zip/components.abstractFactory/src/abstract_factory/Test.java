package abstract_factory;

public class Test {

	public static void main(String[] args) {
		
		System.out.println("Configurations prices:");
		
		Configurator cfg = new Configurator("A");
		System.out.println(cfg.getPrice());
		
		
		Configurator cfg2 = new Configurator("B");
		System.out.println(cfg2.getPrice());		

	}

}