package abstract_factory;

public abstract class Item {
	public abstract double getPrice();
}
