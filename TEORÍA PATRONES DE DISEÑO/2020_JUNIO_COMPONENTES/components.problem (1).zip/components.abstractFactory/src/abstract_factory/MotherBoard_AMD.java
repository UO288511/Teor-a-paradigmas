package abstract_factory;

public class MotherBoard_AMD extends Item{
	@Override
	public double getPrice(){
		return 90;
	}
}
