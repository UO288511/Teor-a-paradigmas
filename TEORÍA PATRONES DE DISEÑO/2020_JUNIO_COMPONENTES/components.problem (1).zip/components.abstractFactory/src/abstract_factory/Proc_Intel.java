package abstract_factory;

public class Proc_Intel extends Item{

	@Override
	public double getPrice(){
		return 800;
	}
}
