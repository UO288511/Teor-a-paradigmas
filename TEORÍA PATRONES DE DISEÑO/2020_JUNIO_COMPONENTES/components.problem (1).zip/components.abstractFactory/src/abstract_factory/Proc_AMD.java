package abstract_factory;

public class Proc_AMD extends Item{

	@Override
	public double getPrice(){
		return 1000;
	}
}
