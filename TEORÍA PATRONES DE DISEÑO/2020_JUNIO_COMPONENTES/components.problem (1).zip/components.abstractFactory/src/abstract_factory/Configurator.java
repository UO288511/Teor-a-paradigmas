package abstract_factory;


public class Configurator {

	private String configuration;

	public Configurator(String s){
		configuration = s;
	}

	public double getPrice(){
		double total = 0;
		Item p = null;
		Item pb = null;

		switch(configuration){
		case "A":
			p = new Proc_Intel();
			pb = new MotherBoard_Intel();
			break;

		case "B": 
			p = new Proc_AMD();
			pb = new MotherBoard_AMD();
			break;
		}

		total = p.getPrice() + pb.getPrice();

		return total;
	}
}

