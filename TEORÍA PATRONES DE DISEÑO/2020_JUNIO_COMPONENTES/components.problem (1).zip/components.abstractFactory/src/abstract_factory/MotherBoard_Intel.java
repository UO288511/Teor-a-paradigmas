package abstract_factory;

public class MotherBoard_Intel  extends Item{
	@Override
	public double getPrice(){
		return 150;
	}
}
