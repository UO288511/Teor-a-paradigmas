package command;

public class Order {
	// class with the list of bought components
	
	@Override 
	public String toString() {
		return "The order description";
	}
}
