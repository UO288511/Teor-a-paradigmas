package command;

public class TechAgent {
	private static int counter = 1; // Ag
	private int id; // Agent identifier
	
	public TechAgent() {
		this.id = TechAgent.counter++; // automatic identification of the agent
	}
	public void getComponents(Order o) {
		System.out.print("Agent" + id + ": "); 
		System.out.println("Getting components of the order: " + o);
	}
	public void connectComponents(Order o) {
		System.out.print("Agent" + id + ": "); 
		System.out.println("Connecting components of the order: " + o);
	}
	public void testComponents(Order o) {
		System.out.print("Agent" + id + ": "); 
		System.out.println("Testing components of the order: " + o);
	}
	public void packComponents(Order o) {
		System.out.print("Agent" + id + ": "); 
		System.out.println("Packing components of the order: " + o);
	}
	public void sendComponents(Order o) {
		System.out.print("Agent" + id + ": "); 
		System.out.println("Sending components of the order: " + o);
	}
}
