package command;



public class Test {

	public static void main(String[] args) {
		// create an order
		Order o1 = new Order();
		// create a Configurator object
		Configurator cfg = new Configurator();
		
		// process the order
		cfg.processOrder(o1);
	}
}
