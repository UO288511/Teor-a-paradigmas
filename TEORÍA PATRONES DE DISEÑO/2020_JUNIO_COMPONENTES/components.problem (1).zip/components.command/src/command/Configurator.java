package command;

public class Configurator {

	public void processOrder(Order o) {
		// create agent
		TechAgent t1 = new TechAgent();

		// Ensemble components
		t1.getComponents(o);
		t1.connectComponents(o);
		t1.testComponents(o);


		// pack and send
		t1.packComponents(o);
		t1.sendComponents(o);
	}
	
	/**
	 *  Este m�todo excutePlan() debe formar parte de la soluci�n y en �l se debe completar:
	 *  - su argumento: el plan creado por el m�todo processOrder() 
	 *  - y el c�digo de su cuerpo: ejecutar todas las acciones del plan recibido como argumento
	 */
	
	private void executePlan(/* el plan creado por processOrder() */) {
		/* ejecuta todas las acciones del plan recibido como argumento*/
	}
	
}

